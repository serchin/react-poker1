import React from 'react';

const WinScreen = () => <div> You Win! </div>

export default WinScreen;