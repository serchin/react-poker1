const railStyle = {
  width: '100%',
  height: 3,
  borderRadius: 50,
  backgroundColor: 'lightgray',
}

export { railStyle }