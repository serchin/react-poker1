import React from 'react';

function Track ({ source, target, getTrackProps }) {
  return(
    <div
    style={{
        position: 'absolute',
        zIndex: 1,
        backgroundColor: 'white',
        cursor: 'pointer',
        left: `${source.percent}%`,
        width: `${target.percent - source.percent}%`,
    }}
    {...getTrackProps()}
    />
  )
}
  
export default Track;