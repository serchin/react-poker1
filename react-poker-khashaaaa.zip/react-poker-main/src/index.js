import reactDom from 'react-dom'
import App from './App'
import './style/global.css'

const rootElement = document.getElementById("root");
reactDom.render(<App />, rootElement)
